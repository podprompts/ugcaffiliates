// src/app/api/ai/generate-video/route.ts
// Generates AI product videos using RunwayML (cinematic) or Replicate/Wan (quick)

import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { title, description, category, style } = await req.json()

    if (!title || !description) {
      return NextResponse.json({ error: 'Title and description required' }, { status: 400 })
    }

    const prompt = `${style === 'cinematic' ? 'Cinematic product advertisement' : 'Authentic UGC style video'} featuring ${title}. ${description.slice(0, 150)}. ${category} product. Professional lighting, smooth camera movement, visually compelling.`

    if (style === 'cinematic') {
      // RunwayML Gen-3 Alpha Turbo
      const response = await fetch('https://api.dev.runwayml.com/v1/image_to_video', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.RUNWAY_API_KEY}`,
          'Content-Type': 'application/json',
          'X-Runway-Version': '2024-11-06',
        },
        body: JSON.stringify({
          model: 'gen3a_turbo',
          promptText: prompt,
          duration: 5,
          ratio: '1280:768',
          promptImage: 'https://placehold.co/1280x768/f2f0ec/888888?text=Product',
        }),
      })

      if (!response.ok) {
        const err = await response.text()
        console.error('[runway] error:', err)
        return NextResponse.json({ error: 'RunwayML generation failed' }, { status: 500 })
      }

      const task = await response.json()
      const taskId = task.id

      // Poll for completion
      let result: any = null
      for (let i = 0; i < 60; i++) {
        await new Promise(r => setTimeout(r, 5000))
        const poll = await fetch(`https://api.dev.runwayml.com/v1/tasks/${taskId}`, {
          headers: {
            'Authorization': `Bearer ${process.env.RUNWAY_API_KEY}`,
            'X-Runway-Version': '2024-11-06',
          },
        })
        result = await poll.json()
        if (result.status === 'SUCCEEDED') break
        if (result.status === 'FAILED') {
          return NextResponse.json({ error: 'Video generation failed' }, { status: 500 })
        }
      }

      const videoUrl = result?.output?.[0]
      if (!videoUrl) return NextResponse.json({ error: 'No video output' }, { status: 500 })

      return NextResponse.json({ video_url: videoUrl, style: 'cinematic', credits_used: 3 })

    } else {
      // Replicate — Wan 2.1 text-to-video (quick)
      const response = await fetch('https://api.replicate.com/v1/models/wavespeedai/wan-2.1-t2v-480p/predictions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.REPLICATE_API_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          input: {
            prompt,
            num_frames: 81,
            sample_steps: 30,
            frames_per_second: 16,
          }
        }),
      })

      const prediction = await response.json()
      let result = prediction
      let attempts = 0

      while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
        await new Promise(r => setTimeout(r, 3000))
        const poll = await fetch(`https://api.replicate.com/v1/predictions/${result.id}`, {
          headers: { 'Authorization': `Bearer ${process.env.REPLICATE_API_TOKEN}` }
        })
        result = await poll.json()
        attempts++
      }

      if (result.status !== 'succeeded' || !result.output) {
        return NextResponse.json({ error: 'Video generation failed' }, { status: 500 })
      }

      return NextResponse.json({ video_url: result.output, style: 'quick', credits_used: 1 })
    }

  } catch (err) {
    console.error('[generate-video] error:', err)
    return NextResponse.json({ error: 'Failed to generate video' }, { status: 500 })
  }
}