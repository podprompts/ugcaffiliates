// src/app/api/ai/runway-video/route.ts
// Generates AI product video using RunwayML image-to-video (Gen-3 Alpha Turbo)
// Pro plan only

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase-server'

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization')
    const token = authHeader?.replace('Bearer ', '')
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const supabase = createServiceClient()
    const { data: { user } } = await supabase.auth.getUser(token)
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    // Check Pro plan
    const { data: profile } = await supabase
      .from('profiles')
      .select('stripe_onboarded')
      .eq('id', user.id)
      .single()

    if (!profile?.stripe_onboarded) {
      return NextResponse.json({ error: 'Pro plan required for AI video generation' }, { status: 403 })
    }

    const body = await req.json()
    const { imageUrl, prompt, duration = 10 } = body

    if (!imageUrl || !prompt) {
      return NextResponse.json({ error: 'Image URL and prompt are required' }, { status: 400 })
    }

    const clampedDuration = Math.min(Math.max(parseInt(duration), 5), 10)

    // RunwayML enforces a 1000 character limit on promptText
    const clampedPrompt = prompt.trim().slice(0, 1000)

    // Create RunwayML image-to-video task
    const response = await fetch('https://api.dev.runwayml.com/v1/image_to_video', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.RUNWAY_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': '2024-11-06',
      },
      body: JSON.stringify({
        model: 'gen4_turbo',
        promptImage: imageUrl,
        promptText: clampedPrompt,
        duration: clampedDuration,
        ratio: '720:1280',
        watermark: false,
      }),
    })

    if (!response.ok) {
      const err = await response.text()
      console.error('[runway] create task error:', err)
      return NextResponse.json({ error: 'Failed to start video generation' }, { status: 500 })
    }

    const task = await response.json()
    const taskId = task.id

    // Poll for completion (max 5 minutes)
    for (let i = 0; i < 60; i++) {
      await new Promise(r => setTimeout(r, 5000))

      const poll = await fetch(`https://api.dev.runwayml.com/v1/tasks/${taskId}`, {
        headers: {
          'Authorization': `Bearer ${process.env.RUNWAY_API_KEY}`,
          'X-Runway-Version': '2024-11-06',
        },
      })

      const result = await poll.json()

      if (result.status === 'SUCCEEDED') {
        const videoUrl = result.output?.[0]
        if (!videoUrl) return NextResponse.json({ error: 'No video output returned' }, { status: 500 })
        return NextResponse.json({ video_url: videoUrl, duration: clampedDuration })
      }

      if (result.status === 'FAILED') {
        console.error('[runway] task failed:', result)
        return NextResponse.json({ error: 'Video generation failed' }, { status: 500 })
      }
    }

    return NextResponse.json({ error: 'Video generation timed out' }, { status: 504 })

  } catch (err) {
    console.error('[runway-video] error:', err)
    return NextResponse.json({ error: 'Failed to generate video' }, { status: 500 })
  }
}
